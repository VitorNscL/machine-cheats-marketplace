package main

import (
	"task-api/internal/database"
	"task-api/internal/handlers"
	"task-api/internal/models"

	"github.com/gin-gonic/gin"
)

func main() {
	database.Connect()

	database.DB.AutoMigrate(&models.User{}, &models.Task{})

	r := gin.Default()

	r.POST("/users", handlers.CreateUser)
	r.POST("/tasks", handlers.CreateTask)
	r.GET("/users/:user_id/tasks", handlers.GetTasks)
	r.PUT("/tasks/:id/complete", handlers.CompleteTask)

	r.Run(":8080")
}
