package handlers

import (
	"net/http"
	"task-api/internal/database"
	"task-api/internal/models"

	"github.com/gin-gonic/gin"
)

func CreateUser(c *gin.Context) {
	var user models.User

	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	database.DB.Create(&user)

	c.JSON(http.StatusCreated, user)
}
