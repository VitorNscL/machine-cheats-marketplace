package handlers

import (
	"net/http"
	"task-api/internal/database"
	"task-api/internal/models"

	"github.com/gin-gonic/gin"
)

func CreateTask(c *gin.Context) {
	var task models.Task

	if err := c.ShouldBindJSON(&task); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	database.DB.Create(&task)
	c.JSON(http.StatusCreated, task)
}

func GetTasks(c *gin.Context) {
	userID := c.Param("user_id")

	var tasks []models.Task
	database.DB.Where("user_id = ?", userID).Find(&tasks)

	c.JSON(http.StatusOK, tasks)
}

func CompleteTask(c *gin.Context) {
	id := c.Param("id")

	var task models.Task
	database.DB.First(&task, id)

	task.Completed = true
	database.DB.Save(&task)

	c.JSON(http.StatusOK, task)
}
